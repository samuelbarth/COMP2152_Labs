# Sample Coding Questions 01 Week 01
# Samuel Barth-Ibe